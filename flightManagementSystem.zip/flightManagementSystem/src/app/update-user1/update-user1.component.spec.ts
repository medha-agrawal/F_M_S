import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateUser1Component } from './update-user1.component';

describe('UpdateUser1Component', () => {
  let component: UpdateUser1Component;
  let fixture: ComponentFixture<UpdateUser1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateUser1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateUser1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
