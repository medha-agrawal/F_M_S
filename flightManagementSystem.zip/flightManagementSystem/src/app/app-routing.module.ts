import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddUser1Component } from './add-user1/add-user1.component';
import {UpdateUser1Component} from './update-user1/update-user1.component';
import {DeleteUser1Component} from './delete-user1/delete-user1.component';
import { HomeComponent } from './home/home.component';
import{ViewallUser1Component} from './viewall-user1/viewall-user1.component';


const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch: 'full'},
  {path: 'home',component:HomeComponent},
  {path:'addUser1', component:AddUser1Component},
  {path:'deleteUser1', component:DeleteUser1Component},
  {path:'updateUser1', component:UpdateUser1Component},
  {path:'viewallUser1', component:ViewallUser1Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
