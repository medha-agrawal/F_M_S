import { User1 } from './user1';

describe('User1', () => {
  it('should create an instance', () => {
    expect(new User1()).toBeTruthy();
  });
});
