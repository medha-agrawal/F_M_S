import { Component, OnInit } from '@angular/core';
import { User1 } from '../user1';
import { User1Service } from '../user1.service';

@Component({
  selector: 'app-viewbyid',
  templateUrl: './viewbyid.component.html',
  styleUrls: ['./viewbyid.component.css']
})
export class ViewbyidComponent implements OnInit {

  user1:User1;
  userId:number;

  constructor(private user1service:User1Service) { }

  ngOnInit(): void {
  }

  viewById(){
    console.log(this.userId);
    this.user1service.viewById(this.userId).subscribe((data)=>{
      data = JSON.parse(data);
      if(data != null){
        this.user1 = data as User1;
        console.log(this.user1.userId);
      }
      else{
        alert("user is not present");
      }
    });
  }

}
