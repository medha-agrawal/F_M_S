import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallUser1Component } from './viewall-user1.component';

describe('ViewallUser1Component', () => {
  let component: ViewallUser1Component;
  let fixture: ComponentFixture<ViewallUser1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallUser1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallUser1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
