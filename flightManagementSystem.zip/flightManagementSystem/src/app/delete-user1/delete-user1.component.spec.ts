import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteUser1Component } from './delete-user1.component';

describe('DeleteUser1Component', () => {
  let component: DeleteUser1Component;
  let fixture: ComponentFixture<DeleteUser1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteUser1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteUser1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
