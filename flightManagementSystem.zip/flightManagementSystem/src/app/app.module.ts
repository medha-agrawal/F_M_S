import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddUser1Component } from './add-user1/add-user1.component';
import { DeleteUser1Component } from './delete-user1/delete-user1.component';
import { UpdateUser1Component } from './update-user1/update-user1.component';
import { ViewallUser1Component } from './viewall-user1/viewall-user1.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { ViewbyidComponent } from './viewbyid/viewbyid.component';

@NgModule({
  declarations: [
    AppComponent,
    AddUser1Component,
    DeleteUser1Component,
    UpdateUser1Component,
    ViewallUser1Component,
    HomeComponent,
    ViewbyidComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
