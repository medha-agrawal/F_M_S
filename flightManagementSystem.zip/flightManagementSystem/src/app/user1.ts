export class User1 {
    userId:number;
    userType:string;
    userName:string;
    userPassword:number;
    userEmail:string;
}
