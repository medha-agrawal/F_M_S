import { Component, OnInit } from '@angular/core';
import {User1 } from '../user1';
import { User1Service } from '../user1.service'; 

@Component({
  selector: 'app-update-user1',
  templateUrl: './update-user1.component.html',
  styleUrls: ['./update-user1.component.css']
})
export class UpdateUser1Component implements OnInit {
  User1:User1=new User1();
  msg:String;
  errorMsg:String;

  constructor(private user1Service:User1Service) { }

  ngOnInit(): void {
  }
  updateUser1(){
    this.user1Service.addUser1(this.User1).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.User1=new User1()},
      error=>{alert("Invalid Modification");});
}
}