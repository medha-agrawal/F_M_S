import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewByIdComponent } from './view-by-id.component';

describe('ViewByIdComponent', () => {
  let component: ViewByIdComponent;
  let fixture: ComponentFixture<ViewByIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewByIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
